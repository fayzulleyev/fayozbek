api_token = ""

from buttons import citiMenu
import requests

from aiogram import Bot,Dispatcher,executor,types
bot = Bot(token=api_token)
dp=Dispatcher(bot)


@dp.message_handler(commands="start")
async def start(message:types.Message):
    await message.answer(f"Salom {message.from_user.full_name} Xush kelibsiz😃")
    print(message)


@dp.message_handler(commands="weather")
async def weather(message:types.Message):
    await message.answer("Shahringizni tanlang",reply_markup=citiMenu)
@dp.message_handler()
async def bott(message:types.Message):
    city = message.text
    api_keys = "ae74493988b0eb6f329e392f929a92ca"
    url = 'https://api.openweathermap.org/data/2.5/weather?q=' + f'{city}' + "&appid=" + api_keys
    res = requests.get(url)
    result = round(res.json()['main']['temp'] - 273)


    await message.answer(f"🌏Shahar: <b>{city}</b> \n ⛅️Harorat: <b>{result}</b>",parse_mode='HTML')


executor.start_polling(dp)