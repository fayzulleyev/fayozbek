from aiogram.types import KeyboardButton,ReplyKeyboardMarkup

citiMenu = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton(text="Samarqand"),
            KeyboardButton(text="Navoi"),
        ],
[
            KeyboardButton(text="Toshkent"),
            KeyboardButton(text="Buxoro"),
        ],
[
            KeyboardButton(text="Qashqadaryo"),
            KeyboardButton(text="Xorazm"),
        ],
[
            KeyboardButton(text="Jizzax"),
            KeyboardButton(text="Surxondaryo"),
        ],
[
            KeyboardButton(text="Sirdaryo"),
            KeyboardButton(text="Andijon"),
        ],
[
            KeyboardButton(text="Namangan"),
            KeyboardButton(text="Farg'ona"),
        ]
    ],resize_keyboard=True
)
