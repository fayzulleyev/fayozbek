import requests

api_keys = "ae74493988b0eb6f329e392f929a92ca"
url = 'https://api.openweathermap.org/data/2.5/weather?q=' + 'samarkand' + "&appid=" + api_keys
res = requests.get(url=url)
result = res.json()['main']['temp']
print(result-273)
